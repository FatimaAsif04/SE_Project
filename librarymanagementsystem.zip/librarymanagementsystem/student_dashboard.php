<?php
session_start();
require_once "config.php";

// Check if the user is logged in as a student
if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'student') {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard</title>
    <link rel="stylesheet" href="styles.css"> <!-- External CSS -->
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        /* Navbar Styling */
        .navbar {
            background: #444;
            color: white;
            padding: 10px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: fixed;
            width: 100%;
            top: 0;
            left: 0;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            z-index: 1000;
        }
        .navbar h1 { font-size: 20px; margin: 0; }
        .navbar ul { list-style: none; padding: 0; display: flex; }
        .navbar ul li { margin-left: 20px; }
        .navbar ul li a {
            color: white;
            text-decoration: none;
            font-weight: bold;
            transition: color 0.3s;
        }
        .navbar ul li a:hover { color: #00c853; }

        /* Sidebar Styling */
        .container {
            display: flex;
            margin-top: 70px;
        }
        .sidebar {
            width: 200px;
            background: #333;
            color: white;
            height: 100vh;
            padding: 20px;
            box-sizing: border-box;
            position: fixed;
            top: 50px;
            left: 0;
        }
        .sidebar ul {
            list-style: none;
            padding: 0;
        }
        .sidebar ul li {
            margin: 15px 0;
        }
        .sidebar ul li a {
            color: white;
            text-decoration: none;
            font-weight: bold;
            display: block;
            padding: 8px;
            border-radius: 5px;
            transition: background 0.3s;
        }
        .sidebar ul li a:hover {
            background: #555;
        }

        /* Main Content */
        .main-content {
            margin-left: 260px;
            padding: 20px;
            flex: 1;
            text-align: center;
        }
        .dashboard-container {
            background: white;
            padding: 30px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 500px;
            margin: auto;
            text-align: center;
        }

        /* Footer */
        .footer {
            background: #444;
            color: white;
            text-align: center;
            padding: 15px;
            position: relative;
            bottom: 0;
            width: 100%;
            margin-top: auto;
        }
        .footer a {
            color: #00c853;
            text-decoration: none;
            font-weight: bold;
        }
        .footer a:hover {
            text-decoration: underline;
        }

        /* Welcome Message */
        .welcome-msg {
            font-size: 20px;
            color: #333;
            font-weight: bold;
        }

    </style>
</head>
<body>

    <!-- Navbar -->
    <div class="navbar">
        <h1>Library Management System</h1>
        <ul>
            <li><a href="index.html">Home</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </div>

    <!-- Sidebar & Main Content -->
    <div class="container">
        <div class="sidebar">
            <h3>Library Menu</h3>
            <ul>
                <li><a href="reserve book.html">Reserve Book</a></li>
                <li><a href="borrowing.html">Borrow Book</a></li>
                <li><a href="requestCabin.html">Book Cabin</a></li>
            </ul>
        </div>
        
        <div class="main-content">
            <div class="dashboard-container">
                <h2>Welcome, <?= htmlspecialchars($_SESSION["user"]); ?>!</h2>
                <p class="welcome-msg">Welcome to the student panel. Select an option from the sidebar.</p>
            </div>
        </div>
    </div>

    <div class="footer">
        <p>&copy; 2025 Library Management System. All rights reserved. | <a href="contact.html">Contact Us</a></p>
    </div>

</body>
</html>

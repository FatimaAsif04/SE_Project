<?php
session_start();
require_once 'config.php';

$database = new Database();
$conn = $database->getConnection();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];  // Student ID or Admin ID
    $password = $_POST['password'];
    $role = $_POST['role'];

    if (!$username || !$password || !$role) {
        echo json_encode(["status" => "error", "message" => "All fields are required."]);
        exit;
    }

    // Determine correct table based on role
    if ($role === "student") {
        $query = "SELECT studentID, password FROM addStudents WHERE studentID = ?";
    } elseif ($role === "admin") {
        $query = "SELECT adminID, password FROM Admin WHERE adminID = ?";
    } else {
        echo json_encode(["status" => "error", "message" => "Invalid role selection."]);
        exit;
    }

    $stmt = $conn->prepare($query);
    $stmt->execute([$username]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    // If user does not exist, create a new account automatically
    if (!$user) {
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        if ($role === "student") {
            $insertQuery = "INSERT INTO addStudents (studentID, password) VALUES (?, ?)";
        } elseif ($role === "admin") {
            $insertQuery = "INSERT INTO Admin (adminID, password) VALUES (?, ?)";
        }

        $insertStmt = $conn->prepare($insertQuery);

        if ($insertStmt->execute([$username, $hashedPassword])) {
            $_SESSION['user'] = $username;
            $_SESSION['role'] = $role;
            $redirectUrl = ($role === "admin") ? "admin_dashboard.php" : "student_dashboard.php";
            echo json_encode(["status" => "success", "message" => "Account created successfully!", "redirect" => $redirectUrl]);
            exit;
        } else {
            echo json_encode(["status" => "error", "message" => "Error creating account."]);
            exit;
        }
    }

    // If user exists, verify password
    if (password_verify($password, $user['password'])) {
        $_SESSION['user'] = $username;
        $_SESSION['role'] = $role;
        $redirectUrl = ($role === "admin") ? "admin_dashboard.php" : "student_dashboard.php";
        echo json_encode(["status" => "success", "message" => "Login successful!", "redirect" => $redirectUrl]);
    } else {
        echo json_encode(["status" => "error", "message" => "Incorrect password."]);
    }
}
?>

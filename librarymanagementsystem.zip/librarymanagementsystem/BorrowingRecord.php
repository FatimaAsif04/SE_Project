<?php
require_once 'config.php'; // Ensure this file is correctly placed

header('Content-Type: application/json'); // Set response type to JSON

// Create a database connection
$database = new Database();
$conn = $database->getConnection();

// Check if request is POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $book = $_POST['book'] ?? '';
    $borrowDate = $_POST['borrowDate'] ?? '';
    $returnDate = $_POST['returnDate'] ?? '';

    // Validate required fields
    if (empty($book) || empty($borrowDate) || empty($returnDate)) {
        echo json_encode(["status" => "error", "message" => "Please fill in all required fields."]);
        exit;
    }

    // Validate date format
    if (!validateDate($borrowDate) || !validateDate($returnDate)) {
        echo json_encode(["status" => "error", "message" => "Invalid date format. Use YYYY-MM-DD."]);
        exit;
    }

    // Insert data into the database
    $query = "INSERT INTO borrowing_records (book_name, borrow_date, return_date) VALUES (:book, :borrowDate, :returnDate)";
    $stmt = $conn->prepare($query);

    try {
        $stmt->execute([
            ':book' => $book,
            ':borrowDate' => $borrowDate,
            ':returnDate' => $returnDate
        ]);
        echo json_encode(["status" => "success", "message" => "Borrowing record saved successfully!"]);
    } catch (PDOException $e) {
        echo json_encode(["status" => "error", "message" => "Error saving record: " . $e->getMessage()]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "Invalid request."]);
}

// Function to validate date format (YYYY-MM-DD)
function validateDate($date) {
    return preg_match("/^\d{4}-\d{2}-\d{2}$/", $date);
}
?>

<?php
include 'connection.php';

try {
    // Create a new PDO connection
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Fetch bookings from the database
    $stmt = $pdo->query("SELECT cabin, booking_date, start_time, end_time FROM cabin_bookings ORDER BY booking_date DESC");
    $bookings = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cabin Bookings</title>
    <style>
        table { width: 80%; margin: auto; border-collapse: collapse; }
        th, td { padding: 10px; text-align: left; border: 1px solid #ccc; }
        th { background-color: #444; color: white; }
    </style>
</head>
<body>
    <h2 style="text-align:center;">Cabin Bookings</h2>
    <table>
        <tr>
            <th>Cabin</th>
            <th>Booking Date</th>
            <th>Start Time</th>
            <th>End Time</th>
        </tr>
        <?php if (!empty($bookings)): ?>
            <?php foreach ($bookings as $booking): ?>
                <tr>
                    <td><?= htmlspecialchars($booking['cabin']) ?></td>
                    <td><?= htmlspecialchars($booking['booking_date']) ?></td>
                    <td><?= htmlspecialchars($booking['start_time']) ?></td>
                    <td><?= htmlspecialchars($booking['end_time']) ?></td>
                </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr><td colspan="4" style="text-align:center;">No bookings found</td></tr>
        <?php endif; ?>
    </table>
</body>
</html>

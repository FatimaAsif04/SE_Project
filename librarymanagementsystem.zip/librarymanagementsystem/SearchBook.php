<?php
require_once "config.php";
require_once "SearchBook.php";

// Check if request is POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $keyword = isset($_POST["keyword"]) ? trim($_POST["keyword"]) : "";

    if (!empty($keyword)) {
        $database = new Database();
        $db = $database->getConnection();
        $search = new SearchBook($db);
        $result = $search->searchBook($keyword);

        if ($result->num_rows > 0) {
            echo "<h3 style='color: green;'>Book found!</h3>";
            echo "<ul>";
            while ($row = $result->fetch_assoc()) {
                echo "<li><strong>" . htmlspecialchars($row["title"]) . "</strong> by " . htmlspecialchars($row["author"]) . "</li>";
            }
            echo "</ul>";
        } else {
            echo "<h3 style='color: red;'>No books found.</h3>";
        }
    } else {
        echo "<h3 style='color: red;'>Please enter a search term.</h3>";
    }
}
?>

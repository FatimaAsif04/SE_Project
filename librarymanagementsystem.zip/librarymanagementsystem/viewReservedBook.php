<?php
require_once 'Database.php';
require_once 'Book.php';

// Create a database connection
$database = new Database();
$db = $database->getConnection();

// Fetch reserved books
$book = new Book($db);
$reservedBooks = $book->getReservedBooks();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Reserved Books</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="navbar">
        <h1>Library Management System</h1>
        <ul>
            <li><a href="index.html">Home</a></li>
            <li><a href="#about">About</a></li>
            <li><a href="#contact">Contact</a></li>
        </ul>
    </div>

    <div class="container">
        <h2>Reserved Books</h2>
        <table>
            <tr>
                <th>Book Title</th>
                <th>Author</th>
                <th>Reservation Date</th>
                <th>Student Name</th>
            </tr>
            <?php foreach ($reservedBooks as $book): ?>
            <tr>
                <td><?= htmlspecialchars($book['title']) ?></td>
                <td><?= htmlspecialchars($book['author']) ?></td>
                <td><?= htmlspecialchars($book['reservation_date']) ?></td>
                <td><?= htmlspecialchars($book['student_name']) ?></td>
            </tr>
            <?php endforeach; ?>
        </table>
    </div>

    <div class="footer">
        <p>&copy; 2025 Library Management System. All rights reserved. | <a href="contact.html">Contact Us</a></p>
    </div>
</body>
</html>

<?php
session_start();
require_once 'config.php'; // Include database connection

$database = new Database();
$conn = $database->getConnection();

// Only allow admins to add students
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    echo json_encode(["status" => "error", "message" => "Access denied. Only admins can add students."]);
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $studentId = $_POST['studentId'];
    $password = $_POST['password'];

    // Hash the password before storing
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    // Check if Student ID already exists
    $checkQuery = $conn->prepare("SELECT studentID FROM addStudents WHERE studentID = ?");
    $checkQuery->execute([$studentId]);

    if ($checkQuery->rowCount() > 0) {
        echo json_encode(["status" => "error", "message" => "Student ID already exists"]);
        exit;
    }

    // Insert Student Data into 'addStudents' table
    $query = "INSERT INTO addStudents (studentID, password) VALUES (?, ?)";
    $stmt = $conn->prepare($query);

    try {
        $stmt->execute([$studentId, $hashedPassword]);
        echo json_encode(["status" => "success", "message" => "Student added successfully"]);
    } catch (PDOException $e) {
        echo json_encode(["status" => "error", "message" => "Database error: " . $e->getMessage()]);
    }
}
?>

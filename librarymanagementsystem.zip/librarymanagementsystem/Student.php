<?php
require_once "config.php";

class Student {
    private $conn;

    public function __construct($db) {
        $this->conn = $db;
    }

    public function addStudent($name, $email, $department) {
        // Check if email already exists
        $checkQuery = "SELECT email FROM Students WHERE email = ?";
        $stmt = $this->conn->prepare($checkQuery);
        $stmt->execute([$email]);

        if ($stmt->rowCount() > 0) {
            return ["status" => "error", "message" => "Email already registered"];
        }

        // Insert new student
        $query = "INSERT INTO Students (name, email, department) VALUES (?, ?, ?)";
        $stmt = $this->conn->prepare($query);

        if ($stmt->execute([$name, $email, $department])) {
            return ["status" => "success", "message" => "Student added successfully"];
        } else {
            return ["status" => "error", "message" => "Database error"];
        }
    }
}
?>

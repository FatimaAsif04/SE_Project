<?php
session_start();

class Logout {
    public function __construct() {
        $this->logoutUser();
    }

    private function logoutUser() {
        // Unset all session variables
        $_SESSION = [];

        // Destroy session
        session_destroy();

        // Redirect to index.html instead of login.php
        header("Location: index.html"); 
        exit();
    }
}

// Initialize logout process
new Logout();
?>

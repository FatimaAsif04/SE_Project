<?php
class Database {
    private $servername = "localhost";
    private $username = "root";
    private $password = ""; // Change if needed
    private $dbname = "librarymanagementsystem";
    public $conn;

    public function getConnection() {
        try {
            // Create a temporary connection to check database existence
            $tempConn = new PDO("mysql:host=" . $this->servername, $this->username, $this->password);
            $tempConn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            // Create database if it doesn't exist
            $tempConn->exec("CREATE DATABASE IF NOT EXISTS " . $this->dbname);
            
            // Now connect to the created database
            $this->conn = new PDO("mysql:host=" . $this->servername . ";dbname=" . $this->dbname . ";charset=utf8mb4", $this->username, $this->password);
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            
        } catch (PDOException $exception) {
            die("Connection error: " . $exception->getMessage());
        }
        return $this->conn;
    }
}

// Define constants
define("DB_HOST", "localhost");
define("DB_USER", "root"); 
define("DB_PASS", "");
define("DB_NAME", "librarymanagementsystem");
?>

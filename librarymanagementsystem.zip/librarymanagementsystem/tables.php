<?php
// Include the database configuration file
require_once 'config.php';

// Create a Database instance and get the connection
$database = new Database();
$conn = $database->getConnection();

// Table creation queries
$tables = [
    "Admin" => "CREATE TABLE IF NOT EXISTS Admin (
        adminID INT AUTO_INCREMENT PRIMARY KEY,
        password VARCHAR(255) NOT NULL
    )",
    
    "Students" => "CREATE TABLE IF NOT EXISTS Students (
        studentID INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        email VARCHAR(100) UNIQUE NOT NULL,
        department VARCHAR(50) NOT NULL
    )",
    
    "addStudents" => "CREATE TABLE IF NOT EXISTS addStudents (
        studentID INT AUTO_INCREMENT PRIMARY KEY,
        password VARCHAR(255) NOT NULL
    )",
    
    "Books" => "CREATE TABLE IF NOT EXISTS Books (
        bookID INT AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(255) NOT NULL,
        author VARCHAR(100) NOT NULL,
        availability_status BOOLEAN DEFAULT TRUE
    )",
    
    "BorrowingRecords" => "CREATE TABLE IF NOT EXISTS BorrowingRecords (
        borrowingID INT AUTO_INCREMENT PRIMARY KEY,
        studentID INT,
        bookID INT,
        borrowDate DATE NOT NULL,
        FOREIGN KEY (studentID) REFERENCES Students(studentID),
        FOREIGN KEY (bookID) REFERENCES Books(bookID)
    )",
    
    "ReturningBook" => "CREATE TABLE IF NOT EXISTS ReturningBook (
        returningID INT AUTO_INCREMENT PRIMARY KEY,
        borrowingID INT,
        returnDate DATE NOT NULL,
        FOREIGN KEY (borrowingID) REFERENCES BorrowingRecords(borrowingID)
    )",
    
    "CabinBooking" => "CREATE TABLE IF NOT EXISTS CabinBooking (
        bookingID INT AUTO_INCREMENT PRIMARY KEY,
        studentID INT,
        cabinNo VARCHAR(10) NOT NULL,
        bookingDate DATE NOT NULL,
        startTime TIME NOT NULL,
        endTime TIME NOT NULL,
        FOREIGN KEY (studentID) REFERENCES Students(studentID)
    )"
];

// Loop through tables and execute queries
foreach ($tables as $tableName => $query) {
    try {
        $conn->exec($query);
        echo "$tableName table checked/created successfully.<br>";
    } catch (PDOException $e) {
        echo "Error creating $tableName table: " . $e->getMessage() . "<br>";
    }
}

// Close connection
$conn = null;
?>

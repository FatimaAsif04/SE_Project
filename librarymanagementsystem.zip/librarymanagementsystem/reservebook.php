<?php
session_start();
require_once 'config.php'; // Ensure database connection works

$database = new Database();
$conn = $database->getConnection();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $studentId = isset($_POST['studentId']) ? trim($_POST['studentId']) : null;
    $bookId = isset($_POST['bookId']) ? trim($_POST['bookId']) : null;
    $startDate = isset($_POST['startDate']) ? trim($_POST['startDate']) : null;
    $returnDate = isset($_POST['returnDate']) ? trim($_POST['returnDate']) : null;

    if (!$studentId || !$bookId || !$startDate || !$returnDate) {
        echo json_encode(["status" => "error", "message" => "All fields are required."]);
        exit;
    }

    // Debugging: Log received Student ID
    error_log("Received Student ID: " . $studentId);

    // Check if student exists
    $studentCheck = $conn->prepare("SELECT studentID FROM Students WHERE studentID = :studentId");
    $studentCheck->bindParam(":studentId", $studentId, PDO::PARAM_INT);
    $studentCheck->execute();
    $studentExists = $studentCheck->fetch(PDO::FETCH_ASSOC);

    if (!$studentExists) {
        echo json_encode(["status" => "error", "message" => "Invalid Student ID: " . $studentId]);
        exit;
    }

    // Debugging: Confirm Student Exists
    error_log("Student Found: " . json_encode($studentExists));

    // Check if book is available
    $bookCheck = $conn->prepare("SELECT availability_status FROM Books WHERE bookID = :bookId");
    $bookCheck->bindParam(":bookId", $bookId, PDO::PARAM_INT);
    $bookCheck->execute();
    $book = $bookCheck->fetch(PDO::FETCH_ASSOC);

    if (!$book || $book['availability_status'] == 0) {
        echo json_encode(["status" => "error", "message" => "This book is currently unavailable."]);
        exit;
    }

    // Insert the reservation
    $stmt = $conn->prepare("INSERT INTO BookReservations (studentID, bookID, startDate, returnDate) 
                            VALUES (:studentId, :bookId, :startDate, :returnDate)");
    try {
        $stmt->bindParam(":studentId", $studentId, PDO::PARAM_INT);
        $stmt->bindParam(":bookId", $bookId, PDO::PARAM_INT);
        $stmt->bindParam(":startDate", $startDate);
        $stmt->bindParam(":returnDate", $returnDate);
        $stmt->execute();
        
        // Mark book as reserved
        $updateBook = $conn->prepare("UPDATE Books SET availability_status = 0 WHERE bookID = :bookId");
        $updateBook->bindParam(":bookId", $bookId, PDO::PARAM_INT);
        $updateBook->execute();

        echo json_encode(["status" => "success", "message" => "Book reserved successfully."]);
    } catch (PDOException $e) {
        echo json_encode(["status" => "error", "message" => "Database error: " . $e->getMessage()]);
    }
}
?>

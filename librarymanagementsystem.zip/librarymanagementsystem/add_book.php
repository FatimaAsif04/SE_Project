<?php
require_once "config.php";

class Book {
    private $conn;

    public function __construct($db) {
        $this->conn = $db;
    }

    public function addBook($bookId, $bookName, $author, $availability) {
        // Check if book already exists
        $checkQuery = "SELECT bookID FROM Books WHERE bookID = ?";
        $stmt = $this->conn->prepare($checkQuery);
        $stmt->execute([$bookId]);

        if ($stmt->rowCount() > 0) {
            return ["status" => "error", "message" => "Book ID already exists."];
        }

        // Insert new book
        $query = "INSERT INTO Books (bookID, title, author, availability_status) VALUES (?, ?, ?, ?)";
        $stmt = $this->conn->prepare($query);

        if ($stmt->execute([$bookId, $bookName, $author, $availability])) {
            return ["status" => "success", "message" => "Book added successfully."];
        } else {
            return ["status" => "error", "message" => "Database error."];
        }
    }
}

// Create database instance
$database = new Database();
$conn = $database->getConnection();
$book = new Book($conn);

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $bookId = $_POST["bookId"];
    $bookName = $_POST["bookName"];
    $author = $_POST["author"];
    $availability = $_POST["availability"];

    $response = $book->addBook($bookId, $bookName, $author, $availability);
    echo json_encode($response);
}
?>

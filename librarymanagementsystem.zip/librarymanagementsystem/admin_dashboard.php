<?php
session_start();
require_once "config.php";

// Check if user is logged in and is an admin
if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        body { background-color: #f4f4f4; }
        .navbar { background-color: #343a40; }
        .navbar a { color: white !important; }
        .sidebar {
            height: 100vh;
            width: 250px;
            position: fixed;
            top: 0;
            left: 0;
            background-color: #212529;
            padding-top: 20px;
        }
        .sidebar a {
            padding: 15px;
            display: block;
            color: white;
            text-decoration: none;
            transition: 0.3s;
        }
        .sidebar a:hover {
            background: #007BFF;
        }
        .content {
            margin-left: 260px;
            padding: 20px;
        }
        .footer {
            position: fixed;
            bottom: 0;
            left: 260px;
            width: calc(100% - 260px);
            background: #343a40;
            color: white;
            text-align: center;
            padding: 10px;
        }
    </style>
</head>
<body>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="#">Library Management</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="index.html">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="addbook.html">Books</a></li>
                    <li class="nav-item"><a class="nav-link" href="borrowing.html">Borrowing</a></li>
                    <li class="nav-item"><a class="nav-link" href="requestCabin.html">Cabin Booking</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Sidebar -->
    <div class="sidebar">
        <a href="addstudent.html">Add Student</a>
        <a href="borrowing.html">View Borrowing Records</a>
        <!-- <a href="searchBooks.php">Search Books</a> -->
        <!-- <a href="reservebook.html">Manage Book Reservations</a> -->
        <a href="logout.php" style="background: red;">Logout</a>
    </div>

    <!-- Main Content -->
    <div class="content">
        <h2>Admin Dashboard</h2>
        <p>Welcome to the admin panel. Select an option from the sidebar.</p>
    </div>

    <!-- Footer -->
    <div class="footer">
        <p>&copy; <?php echo date("Y"); ?> Library Management System. All Rights Reserved.</p>
    </div>

</body>
</html>


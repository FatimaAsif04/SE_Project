<?php
require_once "config.php"; // Ensure this file properly initializes a PDO connection

class Book {
    private $conn;
    private $table = "books"; // Table name

    public function __construct($db) {
        $this->conn = $db;
    }

    public function deleteBook($bookId, $bookName) {
        $query = "DELETE FROM " . $this->table . " WHERE book_id = :bookId AND book_name = :bookName";
        $stmt = $this->conn->prepare($query);
        $stmt->bindValue(":bookId", $bookId, PDO::PARAM_INT);
        $stmt->bindValue(":bookName", $bookName, PDO::PARAM_STR);

        return $stmt->execute();
    }
}

// Initialize DB Connection
$database = new Database();
$db = $database->getConnection();
$book = new Book($db);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $bookId = $_POST["bookId"];
    $bookName = $_POST["bookname"];

    if ($book->deleteBook($bookId, $bookName)) {
        echo "<script>alert('Book deleted successfully!'); window.location.href='deleteBook.html';</script>";
    } else {
        echo "<script>alert('Failed to delete book.'); window.location.href='deleteBook.html';</script>";
    }
}
?>

<?php
include 'config.php';
header("Content-Type: application/json");

try {
    // Establish database connection
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Check if the search query is provided
    if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['query'])) {
        $query = trim($_POST['query']);

        // Prepare a search query (Case-insensitive search using LIKE)
        $stmt = $pdo->prepare("SELECT title FROM books WHERE title LIKE :query OR author LIKE :query");
        $stmt->execute(['query' => "%$query%"]);
        $books = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Return JSON response
        echo json_encode($books);
    } else {
        echo json_encode([]);
    }
} catch (PDOException $e) {
    echo json_encode(["error" => "Database connection failed: " . $e->getMessage()]);
}
?>

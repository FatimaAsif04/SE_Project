<?php
require_once "config.php"; // Database connection

class Book {
    private $conn;
    private $table = "books"; // Table name

    public function __construct($db) {
        $this->conn = $db;
    }

    public function updateBook($bookId, $bookName, $author, $availability) {
        $query = "UPDATE " . $this->table . " SET book_name = ?, author = ?, availability = ? WHERE book_id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("sssi", $bookName, $author, $availability, $bookId);

        if ($stmt->execute()) {
            return true;
        }
        return false;
    }
}

// Initialize DB Connection
$database = new Database();
$db = $database->getConnection();
$book = new Book($db);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $bookId = $_POST["bookId"];
    $bookName = $_POST["bookName"];
    $author = $_POST["author"];
    $availability = $_POST["availability"];

    if ($book->updateBook($bookId, $bookName, $author, $availability)) {
        echo "<script>alert('Book updated successfully!'); window.location.href='updateBook.html';</script>";
    } else {
        echo "<script>alert('Failed to update book.'); window.location.href='updateBook.html';</script>";
    }
}
?>

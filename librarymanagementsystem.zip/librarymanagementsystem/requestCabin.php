<?php
session_start();
require_once 'config.php'; // Include database connection

$database = new Database();
$conn = $database->getConnection();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $cabinNo = $_POST['cabinNo'];
    $bookingDate = $_POST['bookingDate'];
    $startTime = $_POST['startTime'];
    $endTime = $_POST['endTime'];
    $studentId = $_SESSION['user']; // Ensure the student is logged in

    if (!$cabinNo || !$bookingDate || !$startTime || !$endTime) {
        echo json_encode(["status" => "error", "message" => "All fields are required."]);
        exit;
    }

    // Check if the selected time is valid
    if ($startTime >= $endTime) {
        echo json_encode(["status" => "error", "message" => "Start time must be before end time."]);
        exit;
    }

    // Check if the student exists
    $studentCheck = $conn->prepare("SELECT studentID FROM Students WHERE studentID = ?");
    $studentCheck->execute([$studentId]);
    if ($studentCheck->rowCount() == 0) {
        echo json_encode(["status" => "error", "message" => "Invalid Student ID."]);
        exit;
    }

    // Check for overlapping bookings
    $overlapCheck = $conn->prepare("SELECT * FROM CabinBooking WHERE cabinNo = ? AND bookingDate = ? AND 
        ((startTime BETWEEN ? AND ?) OR (endTime BETWEEN ? AND ?))");
    $overlapCheck->execute([$cabinNo, $bookingDate, $startTime, $endTime, $startTime, $endTime]);

    if ($overlapCheck->rowCount() > 0) {
        echo json_encode(["status" => "error", "message" => "This cabin is already booked for the selected time."]);
        exit;
    }

    // Insert the booking
    $stmt = $conn->prepare("INSERT INTO CabinBooking (studentID, cabinNo, bookingDate, startTime, endTime) 
                            VALUES (?, ?, ?, ?, ?)");
    try {
        $stmt->execute([$studentId, $cabinNo, $bookingDate, $startTime, $endTime]);
        echo json_encode(["status" => "success", "message" => "Cabin booked successfully."]);
    } catch (PDOException $e) {
        echo json_encode(["status" => "error", "message" => "Database error: " . $e->getMessage()]);
    }
}
?>
